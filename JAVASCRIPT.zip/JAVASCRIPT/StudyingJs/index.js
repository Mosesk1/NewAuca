//a,b returns b,a


function reverse(string){
    
    mystring='';

for(let i = string.length -1 ; i>=0 ; i--){

    let mystring=mystring+string[i];
}
 return mystring;
}
console.log(reverse('a,b'));
