﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Students
{
    public partial class MakeupStatus : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
         string status = "YOUR MAKEUP REQUEST IS APPROVED PAY 25% OF THE COURSE FEES";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();


            if (Session["Users"] == null)
            {
                Response.Redirect("Stlogin.aspx");
            }

            //SqlCommand cmd2 = con.CreateCommand();
            //cmd2.CommandType = CommandType.Text;
            //cmd2.CommandText = "select * from Makeup";
            //cmd2.ExecuteNonQuery();
            //DataTable dt2 = new DataTable();
            //SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            //da2.Fill(dt2);
            //foreach (DataRow dr2 in dt2.Rows)
            //{
            //    status = dr2["status"].ToString();
            //}

            DataTable dt1 = new DataTable();
            dt1.Clear();
            dt1.Columns.Add("Username");
            dt1.Columns.Add("Is_Makeup_Requested");
            dt1.Columns.Add("Is_Makeup_Approved");
            dt1.Columns.Add("Is_Makeup_paidfor");
            dt1.Columns.Add("status");

            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Makeup where Username='" + Session["Users"].ToString() + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                DataRow dr1 = dt1.NewRow();
                dr1["Username"] = dr["Username"].ToString();
                dr1["Is_Makeup_Requested"] = dr["Is_Makeup_Requested"].ToString();
                dr1["Is_Makeup_Approved"] = dr["Is_Makeup_Approved"].ToString();
                dr1["Is_Makeup_paidfor"] = dr["Is_Makeup_paidfor"].ToString();

                if (dr["Is_Makeup_Approved"].ToString() == "no")
                {
                    status = " YOUR MAKEUP REQUEST IS PENDING WAIT FOR AN APPROVAL ";
                }
                else if (dr["Is_Makeup_paidfor"].ToString() == "no")
                {
                    status = " YOUR MAKEUP REQUEST IS APPROVED PAY 25% OF THE COURSE FEES ";
                }
                else if (dr["Is_Makeup_paidfor"].ToString() == "yes")
                {
                    status = " YOUR ARE NOW ELIGIBLE TO ATTEMPT THE MAKEUP ";
                }


                dr1["status"] = status.ToString();

                dt1.Rows.Add(dr1);

            }

            r1.DataSource = dt1;
            r1.DataBind();

        }
    }
        }
    