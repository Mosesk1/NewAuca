﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Students
{
    
    public partial class Proposal : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindBind();
            }

        }

        private void BindBind()
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Faculty";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            if(dt.Rows.Count>0)
            {
                faculty.DataSource = dt;
                faculty.DataTextField = "FacultyName";
                faculty.DataValueField = "FacultyID";
                faculty.DataBind();
            }
        }
        protected void faculty_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select *from Department where FacultyID='" + faculty.SelectedValue.ToString() + "'";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                department.DataSource = dt;
                department.DataTextField = "DepartmentName";
                department.DataValueField = "DeparmentID";
                department.DataBind();
            }
        }
        protected void department_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void b1_Click(object sender, EventArgs e)
        {
            string proposal_pdf = "";

            string path2 = "";

            if (fo2.FileName.ToString() != "")
            {
                proposal_pdf = Class1.GetRandomPassword(10) + ".pdf";
                fo2.SaveAs(Request.PhysicalApplicationPath + "/Students/proposal_pdf/" + proposal_pdf.ToString());
                path2 = "proposal_pdf/" + proposal_pdf.ToString();
            }
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Proposal values('" + id.Text + "','" + firstname.Text + "','" + lastname.Text + "','" + faculty.Text + "','" + department.Text + "','" + path2.ToString() + "','" + Session["Users"].ToString() + "','no','yes')";
            cmd.ExecuteNonQuery();

            con.Close();

            Response.Write("<script> alert('Proposal Submitted Successfully'); </script>");
        }

    }
}