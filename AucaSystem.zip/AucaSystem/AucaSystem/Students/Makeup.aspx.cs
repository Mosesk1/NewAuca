﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Students
{
    public partial class Makeup : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            if (Session["Users"] == null)
            {
                Response.Redirect("Stlogin.aspx");
            }
        }

        protected void b1_Click(object sender, EventArgs e)
        {
            int cash;
            int cr;
            int tot;
            cr = Convert.ToInt32(credits.Text);
            tot = cr * 15000;
            cash = (tot * 25)/100;
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Makeup values('" + id.Text + "','" + firstname.Text + "','" + lastname.Text + "','" + course.Text + "','" + credits.Text + "','" + Session["Users"].ToString() + "','yes','no','no'," + cash + ")";
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('Request sent Successfully'); </script>");
        }
    }
}