﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem
{
    public partial class landing : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lg_Click(object sender, EventArgs e)
        {
            Response.Redirect("Stlogin.aspx");
        }

        protected void b3_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/Adlogin.aspx");
        }

        protected void b4_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Teachers/TeLogin.aspx");
        }
    }
}