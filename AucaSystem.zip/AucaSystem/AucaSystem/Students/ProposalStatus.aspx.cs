﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Students
{
    public partial class ProposalStatus : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
        string status = "YOUR PROPOSAL REQUEST IS APPROVED ";
        protected void Page_Load(object sender, EventArgs e)
        {
             if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();



            if (Session["Users"] == null)
            {
                Response.Redirect("Stlogin.aspx");
            }

            //SqlCommand cmd2 = con.CreateCommand();
            //cmd2.CommandType = CommandType.Text;
            //cmd2.CommandText = "select * from Makeup";
            //cmd2.ExecuteNonQuery();
            //DataTable dt2 = new DataTable();
            //SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            //da2.Fill(dt2);
            //foreach (DataRow dr2 in dt2.Rows)
            //{
            //    status = dr2["status"].ToString();
            //}

            DataTable dt1 = new DataTable();
            dt1.Clear();
            dt1.Columns.Add("StudentID");
            dt1.Columns.Add("FirstName");
            dt1.Columns.Add("LastName");
            dt1.Columns.Add("IsProapproved");
            dt1.Columns.Add("status");

            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Proposal where Username='" + Session["Users"].ToString() + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                DataRow dr1 = dt1.NewRow();
                dr1["StudentID"] = dr["StudentID"].ToString();
                dr1["FirstName"] = dr["FirstName"].ToString();
                dr1["LastName"] = dr["LastName"].ToString();
                dr1["IsProapproved"] = dr["IsProapproved"].ToString();
                //dr1["IsProrequested"] = dr["IsProrequested"].ToString();

                if (dr["IsProapproved"].ToString() == "no")
                {
                    status = " YOUR PROPOSAL REQUEST IS PENDING WAIT FOR AN APPROVAL ";
                }
                //else if (dr["IsProapproved"].ToString() == "no")
               // {
                //    status = " YOUR P REQUEST IS APPROVED PAY 25% OF THE COURSE FEES ";
               // }
                else if (dr["IsProapproved"].ToString() == "yes")
                {
                    status = " YOUR PROPOSAL REQUEST HAS BEEN APPROVED ";
                }


                dr1["status"] = status.ToString();

                dt1.Rows.Add(dr1);

            }

            r1.DataSource = dt1;
            r1.DataBind();

        }
    
    }
}