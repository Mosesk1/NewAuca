﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Students
{
    public partial class Supervisor : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void b1_Click(object sender, EventArgs e)
        {
            string supervisor_pdf = "";

            string path2 = "";

            if (fo2.FileName.ToString() != "")
            {
                supervisor_pdf = Class1.GetRandomPassword(10) + ".pdf";
                fo2.SaveAs(Request.PhysicalApplicationPath + "/Students/supervisor_pdf/" + supervisor_pdf.ToString());
                path2 = "supervisor_pdf/" + supervisor_pdf.ToString();
            }
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Supervisor values('" + id.Text + "','" + firstname.Text + "','" + lastname.Text + "','" + ProjectName.Text + "','" + Session["Users"].ToString() + "','none','not_able','" + path2.ToString() + "')";
            cmd.ExecuteNonQuery();

            con.Close();

            Response.Write("<script> alert('Supervisor Requested Successfully'); </script>");
        }
    }
}