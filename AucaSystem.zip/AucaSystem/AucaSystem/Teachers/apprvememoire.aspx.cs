﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Teachers
{
    public partial class apprvememoire : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            id = Convert.ToInt32(Request.QueryString["idn2"].ToString());

            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Supervisor set memoire='is_able' where id=" + id + "";
            cmd.ExecuteNonQuery();

            Response.Redirect("Tmemoire.aspx");
        }
    }
}