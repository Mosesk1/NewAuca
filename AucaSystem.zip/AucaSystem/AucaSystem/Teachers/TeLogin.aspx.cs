﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Teachers
{
    public partial class TeLogin : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }

        protected void b1_Click(object sender, EventArgs e)
        {
            int i = 0;
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Teachers where UserName='" + username.Text + "' and Password='" + password.Text + "' ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            i = Convert.ToInt32(dt.Rows.Count.ToString());

            if (i > 0)
            {
                Session["Teachers"] = username.Text;
                Response.Redirect("TeLan.aspx");

            }
            else
            {
                error.Style.Add("display", "block");
            }
        }

       
    }
}