﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace AucaSystem.Admin
{
    public partial class Crystalreport : System.Web.UI.Page
    {
         SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
{
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }
        }

        protected void b1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select * from Supervisor", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            //GridView1.DataSource = ds;
            //GridView1.DataBind();

            ReportDocument r = new ReportDocument();
            r.Load(Server.MapPath("allreport.rpt"));
            r.SetDataSource(ds.Tables["table"]);
            CrystalReportViewer.ReportSource = r;
            r.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, false, "All Students Report");

            //Con.Open();

            //DataTable dt = new DataTable();

            //cmd = new SqlCommand("select EmpFname,EmpLname,Date,Reason,Days,Status from Leave Where Status='Pending'", Con);
            //da = new SqlDataAdapter(cmd);
            //da.Fill(dt);

            //LeaveRep cr = new LeaveRep();
            //cr.Database.Tables["Issue_Books"].SetDataSource(dt);
            //this.crystalReportViewer1.ReportSource = cr;
            //Con.Close();
        }

       
    }
}