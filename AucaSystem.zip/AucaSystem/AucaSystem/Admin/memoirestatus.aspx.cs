﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Admin
{
    public partial class memoirestatus : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
         string status = "YOUR MAKEUP REQUEST IS APPROVED PAY 25% OF THE COURSE FEES";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();


            if (Session["Users"] == null)
            {
                Response.Redirect("Crystalreport.aspx");
            }

            //SqlCommand cmd2 = con.CreateCommand();
            //cmd2.CommandType = CommandType.Text;
            //cmd2.CommandText = "select * from Makeup";
            //cmd2.ExecuteNonQuery();
            //DataTable dt2 = new DataTable();
            //SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            //da2.Fill(dt2);
            //foreach (DataRow dr2 in dt2.Rows)
            //{
            //    status = dr2["status"].ToString();
            //}

            DataTable dt1 = new DataTable();
            dt1.Clear();
            dt1.Columns.Add("Username");
            dt1.Columns.Add("FirstName");
            dt1.Columns.Add("supervisorN");
            dt1.Columns.Add("memoire");
            dt1.Columns.Add("status");

            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Supervisor where Username='" + Session["Users"].ToString() + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                DataRow dr1 = dt1.NewRow();
                dr1["Username"] = dr["Username"].ToString();
                dr1["FirstName"] = dr["FirstName"].ToString();
                dr1["supervisorN"] = dr["supervisorN"].ToString();
                dr1["memoire"] = dr["memoire"].ToString();

                if (dr["memoire"].ToString() == "not_able")
                {
                    status = " YOUR Are Not able for Memoire ";
                }

                else if (dr["memoire"].ToString() == "is_able")
                {
                    status = " YOUR ARE NOW ELIGIBLE TO DO THE PRE-DEFENSE ";
                }


                dr1["status"] = status.ToString();

                dt1.Rows.Add(dr1);

            }

            r1.DataSource = dt1;
            r1.DataBind();

        }
        }
    }
