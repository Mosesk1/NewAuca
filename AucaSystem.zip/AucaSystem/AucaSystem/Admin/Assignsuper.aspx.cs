﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AucaSystem.Admin
{
    public partial class Assignsupsser : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=MOSES-S-PC;Initial Catalog=AucaDb;Integrated Security=True");
        protected void Page_Load(object sensder, EventArgs e)
        {
           

            
        }

        protected void b1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Supervisor set supervisorN= '" + Teachersname.Text + "'  where supervisorN='none'";
            cmd.ExecuteNonQuery();

            con.Close();
             Response.Write("<script> alert('Supervisor Assignned Successfully'); </script>");
             
        }
    }
}